void dummy(float *a);

