#include <stdio.h>

void dummy(float *a){
  printf("Dummy was called\n");
}

