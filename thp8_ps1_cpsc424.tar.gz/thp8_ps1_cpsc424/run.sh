./pi
./pi2
./pi3
./pi4
./div
./vector
